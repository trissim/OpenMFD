import solid
import numpy as np
import numbers
import pudb
from solid.utils import *
import viewscad
import subprocess
import os
import os.path as osp
import math
import sys

chamfer_extrude=solid.import_scad("./chamfer_extrude.scad")
chamfer_extrude=chamfer_extrude.chamfer_extrude
r = viewscad.Renderer(width=800, height=800)

def debug(model,f_name,path="/home/ts/code/projects/mfd/designs/debug"):
    solid.scad_render_to_file(model,osp.join(path,f_name)+".scad")
#generate position list of wells using offset from center
wells_pos_from_center_4 = lambda offset: [[-offset,offset],
                                        [offset, offset],
                                        [-offset, -offset],
                                        [offset, -offset]]
wells_pos_from_center_2 = lambda offset: [[offset,0],
                                        [-offset,0]]

def make_well(dims,shape=None,height=None,dxf=False):
    def circle_cylinder():
        if dxf or (height is None):
            well = solid.circle(r=dims, segments=64)
        else:
            well = solid.cylinder(r=dims, h=height, segments=64, center = True)
        return well
    if dims is None:
        sys.exit("radius needs to be a number")
    if isinstance(dims, numbers.Number):
        well =circle_cylinder()
    elif len(dims)==1:
        if isinstance(dims[1], numbers.Number):
            well =circle_cylinder()
        else:
            sys.exit("radius needs to be a number")
    elif len(dims)==2:
        well = solid.square(dims,center = True)
    elif len(dims)==3:
        well = solid.cube(dims, center = True)
    return well

def wells_top_bottom(center_gap,device_dims=None,shape=None,height=None, positions = None, dxf = False,well_shape=None):
    if well_shape == None:
        well_shape = make_well(device_dims,shape=shape,height=height,dxf=dxf)
    wells = []
    if positions is None:
        offset = radius+radius/2.0
        positions = wells_pos_from_center_2(offset)
    if dxf or (height is None):
        height = 0
    for position in positions:
        if dxf:
            wells.append(solid.translate([position[0],position[1]])(well_shape))
        else:
            wells.append(solid.translate([position[0],position[1],height/2.0])(well_shape))
    return  union()(*wells)

#place wells in four corners 
def four_corner(radius,square=True,height=None, positions = None, dxf = False):
    #if well pos not specified set
    #to equally spaced by half radius
    if positions is None:
        offset = radius+radius/2.0
        positions = wells_pos_from_center_4(offset)
    if dxf or (height is None):
        height = 0
    #make wells at positions with specified radius and height
    wells = []
    for position in positions:
        if square:
            #make square if making dxf
            if dxf:
                #well_shape = solid.circle(r=radius, segments=64)
                well_shape = solid.square(size=radius, center=True)
                well_shape = solid.translate([position[0],position[1]])(well_shape)
            #if stl make cube
            else:
                well_shape = solid.cube(size=[radius,radius,height],center=True)
                well_shape = solid.translate([position[0],position[1],height/2.0])(well_shape)
        #do circle and cycliner
        else:
            if dxf:
                well_shape = solid.circle(r=radius, segments=64)
                well_shape = solid.translate([position[0],position[1]])(well_shape)
            #if stl make cylinder
            else:
                well_shape = solid.cylinder(r=radius, h=height, segments=64, center = True)
                well_shape = solid.translate([position[0],position[1],height/2.0])(well_shape)
        wells.append(well_shape)
    #for position in positions:
    #    #make circle if making dxf
    #    if dxf:
    #        well_shape = solid.circle(r=radius, segments=64)
    #        well_shape = solid.translate([position[0],position[1]])(well_shape)
    #    #if stl make cylinder
    #    else:
    #        well_shape = solid.cylinder(r=radius, h=height, segments=64, center = True)
    #        well_shape = solid.translate([position[0],position[1],height/2.0])(well_shape)
    #    wells.append(well_shape)
    return  union()(*wells)

#generate channels 
def make_channels(length,width,height=0,num_chans=1,max_chans=None,spacing=None, dxf = False,
                  rotate_channels=False):
    if dxf or (height is None):
        height = 0
    #if channel gap not defined, is equal to
    if spacing is None: spacing = width
    #calculate number of channels if fitting max num within given width
    if not max_chans is None:
        import math
        num_chans = math.floor((max_chans-spacing)/(width+spacing))
    #get total width of channel section  
    total_width = (width*num_chans)+(spacing*(num_chans-1))

    #make template channel
    #if rotate_channels: width, length = length, width
    if dxf:
        channel_t = solid.square([length,width],center = True)
    else:
        channel_t = solid.cube([length,width,height], center = True)

    #if number channels is even, offset the first channel to center its gap
    if num_chans % 2 == 0: centering = -(width/2.0+spacing/2.0)
    else: centering = 0
    #move template channel up to align bottom at z = 0 
    #and offset center if necessary
    if dxf:
        channel_t = solid.translate([0,centering])(channel_t)
    else:
        channel_t = solid.translate([0,centering,height/2.0])(channel_t)

    #if rotate_channels: length,width = width,length
    #start making the channels
    channels = []
    for i in range(num_chans):
        #if i=0 there is no translation
        #if i=1, we make the first channel adjacent to second
        direction = i

        #if i>=1, we add channels alternating left and right
        if i >= 1:
            direction = -(i/2.0)
            if i % 2 == 1: direction = (-direction)+0.5
                
        #make channel at right position and add it to channel list
        translation_coords = [0,direction*(width+spacing)]
        #if rotate_channels: translation_coords = [direction*(width+spacing),0]
        if dxf:
            channel = solid.translate(translation_coords)(channel_t)
        else:
            channel = solid.translate([*translation_coords,0])(channel_t)
        channels.append(channel)
    
    #group all channels as one object
    channels = union()(*channels)
    #compute the x,y,z dimensions in order to pass as arguments 
    #for construction of other parts of device (such as the chambers)
    measurements = {'x':(length/2.0,-length/2.0),
                    'y':(total_width/2.0,-total_width/2.0)}
    if not dxf:
        measurements['z'] = (height,0)
    if rotate_channels:
        channels = solid.rotate(90)(channels)
        measurements['x'],measurements['y']=measurements['y'],measurements['x']
    return channels,measurements

def make_chambers(msrs,height=None,extra=0,len_until=None,width=None, dxf = False):
    #computes x,y,z length
    total = lambda x : abs(x[0]) + abs(x[1])
    
    #if specific height if specified
    #otherwise use same height as channels
    if dxf:
        pass
    elif not height is None:
        msrs['z'] = (height,0)
    else:
        msrs['z'] = (0,0)
        
    #make copy of measurements from channels to modify chamber dimensions 
    #and add length to chambers as specified
    import pudb
    chamber_dims = msrs.copy()
    #calculate length of chamber to reach specified offset
    if not len_until is None:
        chamber_len = len_until-(msrs['x'][0])
    #or add specified length to channel length (if not specified, adds 0)
    else:
        chamber_len = msrs['x'][0]+extra
    #set the chamber length based 
    chamber_dims['x'] = (chamber_len/2.0,-(chamber_len/2.0))
    #compute final dimensions of chamber
    if not width is None:
        chamber_dims['y'] = (width/2.0,-width/2.0)
    chamber_dims = [total(size) for size in chamber_dims.values()]
        
    #calculate chamber translation offset to place adjacent to channels
    chamber_trslt = msrs['x'][0]+(chamber_len/2.0)
    #compute chamber translation coordinates to align with channels
    #x = 1 moves chamber above channels
    #x = -1 moves chamber below channels
    if dxf:
        trslt = lambda x : [x*(chamber_trslt),0]
    else:
        trslt = lambda x : [x*(chamber_trslt),0,msrs['z'][0]/2.0]
    
    #function to make chamber at top or at bottom 
    if dxf:
        move = lambda x : solid.translate(trslt(x))(solid.square(chamber_dims, center = True) )
    else:
        move = lambda x : solid.translate(trslt(x))(solid.cube(chamber_dims,center = True))
    #make top and bottom chambers and return them as grouped
    top = move(1)
    bottom = move(-1)
    #chambers=solid.rotate(90)(solid.union()(top,bottom))
    chambers=(solid.union()(top,bottom))

    return chambers

#create alignment features 
def alignment_features(unit,dims,grid_size, mask_size = None, alignment = "hollow", units_from_center = (2.5,2.5), corner_len=None):
    width = grid_size[0]*dims[0]
    length = grid_size[1]*dims[1]
    if mask_size is None and corner_len is None:
        corner_len = (dims[0] + dims[1]) /2 / 8
    corner = lambda thickness_div : solid.union()( solid.square([corner_len,corner_len/thickness_div],center=False), solid.square([corner_len/thickness_div,corner_len],center=False) )
    
    def make_full(thickness_div):
        thickness = corner_len/thickness_div
        tr = solid.translate([0, 0, 0 ])(solid.rotate(180)(corner(thickness_div)))
        tr = solid.translate([thickness/2,thickness/2,0])(tr)
        bl = solid.translate([0, 0, 0 ])(solid.rotate(0)(corner(thickness_div)))
        bl = solid.translate([-thickness/2,-thickness/2,0])(bl)
        return solid.union()(tr,bl)
    
    def make_hollow(thickness_div):
        thickness = corner_len/(thickness_div/2)
        inner = make_full(thickness_div)
        outer = make_full(thickness_div/2)
        hollow = outer - inner 
        return hollow
    
    center = (width /2 , length/2)
    mask_pos = lambda x,y : (center[0] + x*(float(units_from_center[0])*dims[0]), center[1] + y*(float(units_from_center[1])*dims[1]))
    positions = []
    positions.append(mask_pos(1,0))
    positions.append(mask_pos(0,1))
    positions.append(mask_pos(-1,0))
    positions.append(mask_pos(0,-1))
    make_mask = lambda mtype : make_hollow(8) if mtype == "hollow" else make_full(8)
    masks = [ solid.translate([*position,0])(make_mask(alignment)) for position in positions]
    
    solid.scad_render_to_file(solid.union()(*masks),"./designs/open_chamber/masks.scad")
    #return unit - solid.union()(*masks)
    return solid.union()(*masks,unit)

def create_outline(thickness, array, dims, grid_size,):
    width = grid_size[0]*dims[0] + thickness *2
    length = grid_size[1]*dims[1] + thickness *2
    outer = solid.translate([-thickness, -thickness,0])(solid.square([width, length]))
    return outer-array

def create_wall(wall_thickness, outline_thickness, dims, grid_size, wall_height = 2000, dxf = False):
    inner_width = grid_size[0]*dims[0] + outline_thickness *2
    inner_length = grid_size[1]*dims[1] + outline_thickness *2
    outer_width = inner_width + wall_thickness * 2
    outer_length = inner_length + wall_thickness * 2
    outer_pos_x = -outline_thickness-wall_thickness
    outer_pos_y = -outline_thickness-wall_thickness
    inner_pos_x = -outline_thickness
    inner_pos_y = -outline_thickness
    if dxf:
        inner_wall = solid.translate([inner_pos_x,
                                      inner_pos_y,
                                      0])(solid.square([inner_width, inner_length]))
        outer_wall = solid.translate([outer_pos_x,
                                      outer_pos_y,
                                      0])(solid.square([outer_width, outer_length]))

        return outer_wall-inner_wall
    else:
        inner_wall = solid.translate([inner_pos_x,
                                      inner_pos_y,
                                      0])(solid.cube([inner_width, inner_length,wall_height]))
        outer_wall = solid.translate([outer_pos_x,
                                      outer_pos_y,
                                      0])(solid.cube([outer_width, outer_length,wall_height]))

        return outer_wall-inner_wall, {'wall_height': wall_height,
                                       'wall_thickness': wall_thickness,
                                       'inner_width':inner_width,
                                       'inner_length': inner_length,
                                       'outer_width': outer_width,
                                       'outer_length': outer_length,
                                       'outer_pos_x' : outer_pos_x,
                                       'outer_pos_y' : outer_pos_y,
                                       'inner_pos_x' : inner_pos_x,
                                       'inner_pos_y' : inner_pos_y}

def create_thicker_wall(wall_thickness, outer_wall_offset, wall_dims, dims, grid_size, height_start = .2, height_end=2, dxf = False):
    addon_wall,thicker_wall_dims = create_wall(wall_thickness, outer_wall_offset, dims, grid_size, wall_height=height_end-height_start, dxf = False)
    addon_wall = solid.translate([0,0,height_start])(addon_wall)

    thicker_wall_dims['wall_height'] = height_end
    thicker_wall_dims['wall_thickness'] = wall_dims['wall_thickness'] + wall_thickness
    return addon_wall, thicker_wall_dims
 
def add_lock_to_wall(wall,wall_dims,y_offset = 0,cut_ratio=0.7,L_length=3, gap_ratio=0.05, axis="x",width_ratio=1/2):
    # Makes L shape
    def make_L(max_length,length_thickness,max_width,width_thickness,height,y_offset):
        length = solid.cube([max_length,length_thickness,height])
        width = solid.cube([width_thickness,max_width,height])
        width = solid.translate([max_length-(width_thickness),0,0])(width)
        L = solid.union()(width,length)
        debug(L,"L")
        if axis == "x":
            L = solid.rotate(-90)(L)
            L = solid.translate([0,max_length,0])(L)
        else:
            L = solid.rotate(-180)(L)
            L = solid.translate([max_length,max_width,0])(L)
        return solid.translate([0,0,y_offset])(L)
    
    lock_length = L_length
    lock_width = wall_dims['wall_thickness']*width_ratio
    lock_length_thickness = lock_width/2
    lock_width_thickness = lock_width/2
    L_lock = make_L(lock_length,lock_length_thickness,lock_width,lock_width_thickness, wall_dims['wall_height']-y_offset, y_offset)
    
    margin_space = lock_length - lock_length*(1-gap_ratio)
    key_length = lock_length-margin_space
    key_length_thickness = lock_length_thickness-(margin_space*2)
    key_width = lock_width-(margin_space*2)
    key_width_thickness = lock_width_thickness-(margin_space*2)
    L_key = make_L(key_length,key_length_thickness,key_width,key_width_thickness, wall_dims['wall_height']-y_offset, y_offset)
    L_key = solid.translate([margin_space,margin_space,0])(L_key)
    L = solid.union()(L_lock,L_key)
    debug(L,"L")
    
    #Make cube to be used as negative to split frame in a half
    #Can choose if making left or right negative, specify ratio of split
    def make_negative(right,cut_ratio):
        if axis == "x":
            if right:
                length = wall_dims['outer_length']*(1-cut_ratio)
                pos_x = wall_dims['outer_pos_x']+(wall_dims['outer_length']*cut_ratio)
            else:
                length = wall_dims['outer_length']*(cut_ratio)
                pos_x = wall_dims['outer_pos_x'] 
            negative = solid.cube([wall_dims['outer_width'],length, wall_dims['wall_height']])
            negative = solid.translate([wall_dims['outer_pos_y'],pos_x,0])(negative)
        else:
            if right:
                length = wall_dims['outer_width']*(1-cut_ratio)
                pos_x = wall_dims['outer_pos_y']+(wall_dims['outer_width']*cut_ratio)
            else:
                length = wall_dims['outer_width']*(cut_ratio)
                pos_x = wall_dims['outer_pos_y'] 
            negative = solid.cube([length,wall_dims['outer_length'], wall_dims['wall_height']])
            negative = solid.translate([pos_x,wall_dims['outer_pos_x'],0])(negative)
        return negative, pos_x, length 
                      
    #Make negatives
    negative_right, right_half_pos_x, right_half_length = make_negative(True,cut_ratio)
    negative_left, left_half_pos_x, right_half_length = make_negative(False,cut_ratio)
    #Make halves
    left_half = solid.difference()(wall,negative_right)
    right_half = solid.difference()(wall,negative_left)
    def place_L(L, L_length,L_width):
        #Place L on top wall       
        offset_to_center = (wall_dims['wall_thickness']-L_width)/2
        if axis == "x":
            y_pos_top = (wall_dims['outer_pos_y'] +
                    wall_dims['outer_width'] - 
                    L_width - offset_to_center)
            top_L = solid.translate([y_pos_top,
                                     right_half_pos_x-(L_length),
                                     0])(L)
            #Place L on bottom wall       
            y_pos_bottom = wall_dims['outer_pos_y']+offset_to_center
            bottom_L = solid.translate([y_pos_bottom,
                                        right_half_pos_x-L_length,
                                        0])(L)
        else:
            y_pos_top = (wall_dims['outer_pos_x'] +
                    wall_dims['outer_length'] -
                    (L_width+offset_to_center))
            top_L = solid.translate([right_half_pos_x-L_length,
                                     y_pos_top,
                                     0])(L)
            #Place L on bottom wall       
            y_pos_bottom = wall_dims['outer_pos_y']+offset_to_center
            bottom_L = solid.translate([right_half_pos_x-L_length,
                                        y_pos_bottom,
                                        0])(L)
        return bottom_L, top_L
    #Make complimentary L pieces through union and differences
    #Make Lock
    bottom_L_lock, top_L_lock = place_L(L_lock,L_length,lock_width)
    left_half = solid.difference()(left_half,bottom_L_lock)
    left_half = solid.difference()(left_half,top_L_lock)
    #Make Key
    bottom_L_key, top_L_key = place_L(L_key,L_length,lock_width)
    right_half = solid.union()(right_half,bottom_L_key)
    right_half = solid.union()(right_half,top_L_key)
    return left_half, right_half


#build a row x col grid of containment units
def make_unit_array(unit,dims,grid_size, dxf = False, alignment = None, mask_size = None,
                    units_from_center = None,alignment_offset=None, alignment_mark_size=1):
    units = []
    for col in range(grid_size[1]):
        for row in range(grid_size[0]):
            if dxf:
                units.append(solid.translate([row*dims[0],col*dims[1]])(unit))
            else:
                units.append(solid.translate([row*dims[0],col*dims[1],dims[2]/2.0])(unit))
    array = solid.union()(*units)
    if (not alignment is None) and dxf:
        if not alignment_offset is None:
            array = solid.translate([alignment_offset[0],alignment_offset[1]])(array)
        array = alignment_features(array,dims, grid_size, alignment = alignment, mask_size = None, units_from_center = units_from_center,corner_len=alignment_mark_size)
        if not alignment_offset is None:
            array = solid.translate([-alignment_offset[0],-alignment_offset[1]])(array)
    return array


def make_taylor(wells_pos = wells_pos_from_center_4(2.25), well_rad = 1.5 ,
                well_height = 2, chan_w = 0.01, chan_l = 1, chan_h = 0.010 ,
                chan_gap = 0.040, max_chans = None,num_chans=100, chamber_height  = 0.100,
                columns = 1, rows = 1, chamber_len_until=2.25, add_channels = True, add_wells = True, 
                add_chambers = True, save_path = "./", alignment = None, units_from_center = 2,
                mask_size = None, render_stl = False, outline_thickness = 0.050, dxf = True,
                wall_height = 15, wall_thickness = 0.95, casing_x=9, casing_y=9, casing_z=0,rotate_units=0):

    dims = [casing_x, casing_y, casing_z]
    wells = four_corner(well_rad,well_height, dxf = dxf, positions = wells_pos)
    debug(wells,"wells")
    channels, msrs = make_channels(chan_l,chan_w,chan_h,dxf=dxf, spacing = chan_gap, max_chans=max_chans,num_chans=num_chans)
    debug(channels,"channels")
    chambers = make_chambers(msrs,dxf = dxf, height=chamber_height,len_until=chamber_len_until)
    debug(chambers,"chambers")

    #add together and render
    device_parts = []
    if add_channels:
        device_parts.append(channels)
    if add_wells:
        device_parts.append(wells)
    if add_chambers:
        device_parts.append(chambers)
    device=union()(*device_parts)
    device = rotate(rotate_units)(device)

    device=solid.translate([dims[0]/2.0,dims[1]/2.0,0])(device)
    channels = rotate(rotate_units)(channels)
    channels=solid.translate([dims[0]/2,dims[1]/2,0])(channels)
    chambers_wells = union()(wells,chambers)
    chambers_wells = rotate(rotate_units)(chambers_wells)
    chambers_wells=solid.translate([dims[0]/2,dims[1]/2,0])(chambers_wells)

    file_name = str(rows)+'x'+str(columns)+'_units_'
    grid_size = [rows,columns]

    if alignment:
        alignment="full"
    device = make_unit_array(device,dims,grid_size, dxf=dxf, alignment = alignment,
                                 units_from_center = units_from_center)
    channels = make_unit_array(channels,dims,grid_size, dxf=dxf, alignment = alignment,
                                 units_from_center = units_from_center)
    if alignment=="full":
        alignment="hollow"

    chambers_wells = make_unit_array(chambers_wells,dims,grid_size, dxf=dxf, alignment = alignment,
                                 units_from_center =units_from_center)

    def save_model(model,prefix):
        model_fname = os.path.abspath(save_path+prefix+"_"+file_name+".scad")
        solid.scad_render_to_file(model,model_fname)
        return model_fname

    wells_fname = save_model(wells,"wells")
    channels_fname = save_model(channels,"channels")
    device_fname = save_model(device,"device")
    chambers_wells_fname = save_model(chambers_wells,"chambers_wells")
    return (chambers_wells,chambers_wells_fname), (channels,channels_fname), (device,device_fname)

def make_device(design='open',rows=8,columns=6,wells_pos = 4.5,well_offset=3.2, well_rad=3.2,well_height=0.1,
                chan_l=1,chan_w=0.01,chan_h=0.01,chan_gap=0.015,num_chans=101,dxf=True,save_path="./designs/open_chamber/",
                casing_x=9.0,casing_y=18.0,casing_z=0,rotate_units=90,units_from_center=(3,1),chamber_len_until=4.5,
                chamber_width=None,alignment=True, add_wells=True, add_channels=True,add_chambers=True,well_shape=None):

    dims = [casing_x, casing_y, casing_z]
    if design == "open":
        wells_pos=wells_pos_from_center_2(wells_pos)
        wells = wells_top_bottom(well_offset*2,device_dims=well_rad,height=well_height, dxf = dxf, positions = wells_pos,well_shape=well_shape)
    elif design == "closed":
        wells_pos=wells_pos_from_center_4(wells_pos)
        debug(wells,"wells")
        wells = four_corner(well_offset,well_height,device_dims=well_rad, dxf = dxf, positions = wells_pos)
    else:
        print(design+" is not a valid design.\n Choose valid design: 'open' or 'closed'")
        exit()
    wells = rotate(rotate_units)(wells)
    wells=solid.translate([dims[0]/2,dims[1]/2,0])(wells)
    debug(wells,"wells")

    channels, msrs = make_channels(chan_l,chan_w,chan_h,dxf=dxf, spacing = chan_gap, num_chans=num_chans,rotate_channels=False)
    channels = rotate(rotate_units)(channels)
    channels=solid.translate([dims[0]/2,dims[1]/2,0])(channels)

    chambers=make_chambers(msrs,height=None,extra=0,len_until=chamber_len_until, width=chamber_width,dxf = dxf)
    chambers = rotate(rotate_units)(chambers)
    chambers=solid.translate([dims[0]/2,dims[1]/2,0])(chambers)

    device_parts = []
    if add_channels:
        device_parts.append(channels)
    if add_wells:
        device_parts.append(wells)
    if add_chambers:
        device_parts.append(chambers)
    device = union()(*device_parts)
    #device = rotate(rotate_units)(device)
    #device=solid.translate([dims[0]/2.0,dims[1]/2.0,0])(device)

    chambers_wells = []
    if add_chambers:
        chambers_wells.append(chambers)
    if add_wells:
        chambers_wells.append(wells)
    chambers_wells = union()(*chambers_wells)
    #chambers_wells = union()(wells,chambers)
    #chambers_wells = rotate(rotate_units)(chambers_wells)
    #chambers_wells=solid.translate([dims[0]/2,dims[1]/2,0])(chambers_wells)

    file_name = str(rows)+'x'+str(columns)+'_units_'

    grid_size = [rows,columns]
    if alignment:
        alignment="full"
    device = make_unit_array(device,dims,grid_size, dxf=dxf, alignment = alignment,
                                 units_from_center = units_from_center)
    channels = make_unit_array(channels,dims,grid_size, dxf=dxf, alignment = alignment,
                                 units_from_center = units_from_center)
    if alignment=="full":
        alignment="hollow"

    chambers_wells = make_unit_array(chambers_wells,dims,grid_size, dxf=dxf, alignment = alignment,
                                 units_from_center =units_from_center)

    def save_model(model,prefix):
        model_fname = os.path.abspath(save_path+prefix+"_"+file_name+".scad")
        solid.scad_render_to_file(model,model_fname)
        return model_fname

    wells_fname = save_model(wells,"wells")
    channels_fname = save_model(channels,"channels")
    device_fname = save_model(device,"device")
    chambers_wells_fname = save_model(chambers_wells,"chambers_wells")
    return (chambers_wells,chambers_wells_fname), (channels,channels_fname), (device,device_fname)


def make_open_chamber(rows=8,columns=6,wells_pos = wells_pos_from_center_2(4.5), well_rad=3.2,well_height=0.1,
                      chan_l=1,chan_w=0.01,chan_h=0.01,chan_gap=0.015,num_chans=101,dxf=True,save_path="./designs/open_chamber/",
                      casing_x=9.0,casing_y=18.0,casing_z=0,rotate_units=90,units_from_center=(3,1),chamber_len_until=4.5,
                      chamber_width=None,alignment=True, add_wells=True, add_channels=True,add_chambers=True,well_shape=None):

    dims = [casing_x, casing_y, casing_z]
    wells = wells_top_bottom(well_rad,height=well_height, dxf = dxf, positions = wells_pos, well_shape=well_shape)
    channels, msrs = make_channels(chan_l,chan_w,chan_h,dxf=dxf, spacing = chan_gap, num_chans=num_chans,rotate_channels=False)
    chambers=make_chambers(msrs,height=None,extra=0,len_until=chamber_len_until, width=chamber_width,dxf = dxf)
    debug(chambers,"chambers")
    device_parts = []
    if add_channels:
        device_parts.append(channels)
    if add_wells:
        device_parts.append(wells)
    if add_chambers:
        device_parts.append(chambers)
    device = union()(*device_parts)
    device = rotate(rotate_units)(device)
    device=solid.translate([dims[0]/2.0,dims[1]/2.0,0])(device)
    channels = rotate(rotate_units)(channels)
    channels=solid.translate([dims[0]/2,dims[1]/2,0])(channels)
    chambers_wells = union()(wells,chambers)
    chambers_wells = rotate(rotate_units)(chambers_wells)
    chambers_wells=solid.translate([dims[0]/2,dims[1]/2,0])(chambers_wells)

    file_name = str(rows)+'x'+str(columns)+'_units_'

    grid_size = [rows,columns]
    if alignment:
        alignment="full"
    device = make_unit_array(device,dims,grid_size, dxf=dxf, alignment = alignment,
                                 units_from_center = units_from_center)
    channels = make_unit_array(channels,dims,grid_size, dxf=dxf, alignment = alignment,
                                 units_from_center = units_from_center)
    if alignment=="full":
        alignment="hollow"

    chambers_wells = make_unit_array(chambers_wells,dims,grid_size, dxf=dxf, alignment = alignment,
                                 units_from_center =units_from_center)

    def save_model(model,prefix):
        model_fname = os.path.abspath(save_path+prefix+"_"+file_name+".scad")
        solid.scad_render_to_file(model,model_fname)
        return model_fname

    wells_fname = save_model(wells,"wells")
    channels_fname = save_model(channels,"channels")
    device_fname = save_model(device,"device")
    chambers_wells_fname = save_model(chambers_wells,"chambers_wells")
    return (chambers_wells,chambers_wells_fname), (channels,channels_fname), (device,device_fname)

def to_dxf(scad_path):
    dxf_path = scad_path.replace(".scad",".dxf")
    subprocess.call(["openscad", "-o", dxf_path, scad_path])
    import ezdxf
    temp_dxf = ezdxf.readfile(dxf_path)
    temp_dxf.saveas(dxf_path)

#def make_walls(diameter,thickness,grid_size,dims,height=20,segments=256,make_inner=True):
#    wafer_wall_out = solid.cylinder(r=diameter/2,h=height, segments=segments)
#    wafer_wall_in = solid.cylinder(r=(diameter/2-thickness),h=height, segments=segments)
#    wafer_wall = solid.difference()(wafer_wall_out,wafer_wall_in)
#    wafer_wall = solid.translate([grid_size[1]*dims[1]/2.0,grid_size[0]*dims[0]/2.0])(wafer_wall)
#
#    vertical_wall_length = grid_size[1]*dims[1]
#    horizontal_wall_length = grid_size[0]*dims[0]
#    vertical_wall = solid.cube([vertical_wall_length,thickness,height],center = True)
#    vertical_wall = solid.translate([vertical_wall_length/2,0,height/2])(vertical_wall)
#    horizontal_wall = solid.cube([thickness,horizontal_wall_length,height],center = True)
#    horizontal_wall = solid.translate([0,vertical_wall_length/2,height/2])(horizontal_wall)
#    walls = []
#    walls.append(horizontal_wall)
#    walls.append(vertical_wall)
#    for col in range(grid_size[1]):
#        if col == grid_size[1]-1: 
#            walls.append(solid.translate([0,(col+1)*dims[1]])(vertical_wall))
#        elif col > 0 and col < grid_size[1]-1 and make_inner==True:
#            walls.append(solid.translate([0,(col+1)*dims[1]])(vertical_wall))
#    for row in range(grid_size[0]):
#        if row == grid_size[0]-1: 
#            walls.append(solid.translate([(row+1)*dims[0],0])(horizontal_wall))
#        elif row > 0 and row < grid_size[0]-1 and make_inner==True:
#            walls.append(solid.translate([(row+1)*dims[0],0])(horizontal_wall))
#    walls = union()(*walls)
#    wafer_walls = union()(walls,wafer_wall)
#    return walls,wafer_wall,wafer_walls

def make_walls(diameter,thickness,grid_size,dims,height=20,segments=256,make_inner=True,padx=0,pady=0):
    wafer_wall_out = solid.cylinder(r=diameter/2,h=height, segments=segments)
    wafer_wall_in = solid.cylinder(r=(diameter/2-thickness),h=height, segments=segments)
    wafer_wall = solid.difference()(wafer_wall_out,wafer_wall_in)
    wafer_wall = solid.translate([grid_size[1]*dims[1]/2.0,grid_size[0]*dims[0]/2.0])(wafer_wall)

    vertical_wall_length = grid_size[0]*dims[0]+padx
    horizontal_wall_length = grid_size[1]*dims[1]+pady
    vertical_wall = solid.cube([vertical_wall_length,thickness,height],center = True)
    vertical_wall = solid.translate([vertical_wall_length/2-pady/2,-padx/2,height/2])(vertical_wall)
    horizontal_wall = solid.cube([thickness,horizontal_wall_length,height],center = True)
    horizontal_wall = solid.translate([-pady/2,horizontal_wall_length/2-padx/2,height/2])(horizontal_wall)
    walls = []
    walls.append(horizontal_wall)
    walls.append(vertical_wall)
    for col in range(grid_size[1]):
        if col == grid_size[1]-1: 
            walls.append(solid.translate([0,(col+1)*dims[1]+pady])(vertical_wall))
        elif col > 0 and col < grid_size[1]-1 and make_inner==True:
            walls.append(solid.translate([0,(col+1)*dims[1]])(vertical_wall))
    for row in range(grid_size[0]):
        if row == grid_size[0]-1: 
            walls.append(solid.translate([(row+1)*dims[0]+padx,0])(horizontal_wall))
        elif row > 0 and row < grid_size[0]-1 and make_inner==True:
            walls.append(solid.translate([(row+1)*dims[0],0])(horizontal_wall))
    walls = union()(*walls)
    wafer_walls = union()(walls,wafer_wall)
    return walls,wafer_wall,wafer_walls

def save_model(model,base_path,base_name,dxf=True):
    if not os.path.exists(base_path):
        os.makedirs(base_path)
    dxf_path=osp.join(base_path,base_name+".scad")
    solid.scad_render_to_file(model,osp.join(dxf_path))
    if dxf:
        to_dxf(dxf_path)

def make_wafer(diameter,flat_len,thickness):
    wafer = solid.cylinder(r1=diameter/2,r2=diameter/2,h=thickness,segments=512,)()
    x_start_flat=(flat_len/2)
    y_start_flat = math.sqrt(((diameter/2)**2) - (x_start_flat**2) )
    height_delete_flat=diameter/2-y_start_flat
    flat_delete = solid.cube([flat_len,height_delete_flat,thickness],center=False)()
    flat_delete = solid.translate([-flat_len/2,y_start_flat,0])(flat_delete)
    wafer = solid.difference()(wafer,flat_delete)
    wafer = solid.rotate(90)(wafer)
    return wafer

def add_wafer_to_mask(wafer_size,flat_len,mask,grid_size,dims,wafer_line_thickness=0.1,outer_mask_thickness=5,alignment_offset=None,shrinkage_scale=1.0):
    def make_wafer_mask(wafer_size,flat_len):
        wafer_mask = make_wafer(wafer_size,flat_len,1)
        wafer_mask = solid.projection()(wafer_mask)
        wafer_mask = solid.translate(np.array([grid_size[0]*dims[0]/2.0,grid_size[1]*dims[1]/2.0])*shrinkage_scale)(wafer_mask)
        if not alignment_offset is None:
            wafer_mask = solid.translate(np.array([-alignment_offset[0],-alignment_offset[1]])*shrinkage_scale)(wafer_mask)
        return wafer_mask

    inner_wafer_line_mask = make_wafer_mask(wafer_size-wafer_line_thickness/2,flat_len)
    outer_wafer_line_mask = make_wafer_mask(wafer_size+wafer_line_thickness/2,flat_len)
    outer_wafer_mask = make_wafer_mask(wafer_size+outer_mask_thickness,flat_len)
    outer_wafer_mask = solid.difference()(outer_wafer_mask,outer_wafer_line_mask)
    wafer_mask = solid.union()(outer_wafer_mask,inner_wafer_line_mask)

    return solid.difference()(wafer_mask,mask)

def make_posts(post_shape,post_height):
    posts = solid.linear_extrude(height=post_height)(post_shape)
    return posts

def make_wafer_empty(diameter,flat_len,thickness,margin,notch_len=20,notch_height=5,oversize=1.01):
    diameter*=oversize
    flat_len*=oversize
    wafer = make_wafer(diameter,flat_len,thickness)
    holder = solid.cylinder(r1=diameter/2+margin,r2=diameter/2+margin,h=thickness,segments=512)()
    holder = solid.difference()(holder,wafer)

    x_start_flat=(flat_len/2)
    y_start_flat = math.sqrt(((diameter/2)**2) - (x_start_flat**2) )
    height_delete_flat=diameter/2-y_start_flat
    notch = solid.cube([notch_len,notch_height,thickness],center=False)()
    notch = solid.translate([-notch_len/2,y_start_flat,0])(notch)
    notch = solid.rotate(90)(notch)
    return solid.difference()(holder,notch)

def wafer_print_calibration(diameter,thickness,height,z_offset):
    circles = []
    radii = []
    radii.append(diameter/2.0*0.8)
    radii.append(diameter/2.0*0.6)
    radii.append(diameter/2.0*0.4)
    radii.append(diameter/2.0*0.2)
    for radius in radii:
        inner = solid.cylinder(r1=radius-(thickness/2.0),r2=radius-(thickness/2.0),h=thickness,segments=512,)()
        outer = solid.cylinder(r1=radius+(thickness/2.0),r2=radius+(thickness/2.0),h=thickness,segments=512,)()
        diff = solid.difference()(outer,inner)
        circles.append(diff)
    circles = solid.union()(*circles)
    circles = solid.translate([0,0,z_offset])(circles)
    return circles

def make_rack(wells,dims,grid_size,alignment_offset,rack_x,rack_y,rack_thickness,bolt_width,add_bolts=True):

    #get X and Y dimensions of gride of pipette tips
    X_len = dims[0]*grid_size[0]
    Y_len = dims[1]*grid_size[1]
    #make rack
    rack = solid.cube([rack_x,rack_y,rack_thickness],center=True)

    if add_bolts:
    #add bolt holes
        bolt_hole=solid.cylinder(r=bolt_width/2,h=rack_thickness,center=True)()
        bolt_holes = []
        bolt_holes.append(solid.translate([rack_x/2-1.5*bolt_width,rack_y/2-1.5*bolt_width])(bolt_hole))
        bolt_holes.append(solid.translate([-rack_x/2+1.5*bolt_width,rack_y/2-1.5*bolt_width])(bolt_hole))
        bolt_holes.append(solid.translate([-rack_x/2+1.5*bolt_width,-rack_y/2+1.5*bolt_width])(bolt_hole))
        bolt_holes.append(solid.translate([rack_x/2-1.5*bolt_width,-rack_y/2+1.5*bolt_width])(bolt_hole))
        bolt_holes = solid.union()(*bolt_holes)
        rack=solid.difference()(rack,bolt_holes)
    rack_support = rack

    #center rack with pipette holes
    rack = solid.translate([0,0,rack_thickness/2])(rack)
    rack = solid.translate([X_len/2,Y_len/2])(rack)
    rack = solid.translate([-alignment_offset[0],-alignment_offset[1]])(rack)
    wells = solid.linear_extrude(height=rack_thickness)(wells)
    rack = solid.difference()(rack,wells)
    return rack, rack_support

def make_pillar(wells,dims,grid_size,alignment_offset,rack_x,rack_y,pillar_height,rack_thickness,bolt_width,add_bolts=True,taper_angle=1,bolt_position_corner=1.5):

    #get X and Y dimensions of gride of pipette tips
    X_len = dims[0]*grid_size[0]
    Y_len = dims[1]*grid_size[1]
    #make rack
    rack = solid.cube([rack_x,rack_y,rack_thickness],center=True)
    
    if add_bolts:
    #add bolt holes
        bolt_hole=solid.cylinder(r=bolt_width/2,h=rack_thickness,center=True)()
        bolt_holes = []
        bolt_holes.append(solid.translate([rack_x/2-bolt_position_corner*bolt_width,rack_y/2-bolt_position_corner*bolt_width])(bolt_hole))
        bolt_holes.append(solid.translate([-rack_x/2+bolt_position_corner*bolt_width,rack_y/2-bolt_position_corner*bolt_width])(bolt_hole))
        bolt_holes.append(solid.translate([-rack_x/2+bolt_position_corner*bolt_width,-rack_y/2+bolt_position_corner*bolt_width])(bolt_hole))
        bolt_holes.append(solid.translate([rack_x/2-bolt_position_corner*bolt_width,-rack_y/2+bolt_position_corner*bolt_width])(bolt_hole))
        bolt_holes = solid.union()(*bolt_holes)
        rack=solid.difference()(rack,bolt_holes)
    rack_support = rack

    #center rack with pipette holes
    #rack = solid.translate([0,0,-rack_thickness])(rack)
    rack = solid.translate([X_len/2,Y_len/2])(rack)
    rack = solid.translate([-alignment_offset[0],-alignment_offset[1]])(rack)
    if not taper_angle == 0:
        wells=chamfer_extrude(pillar_height,taper_angle,segments=20)(wells)
    else:
        wells = solid.linear_extrude(height=pillar_height)(wells)
    rack = solid.union()(rack,wells)
    return rack, rack_support

def deg_taper_len(height,deg):
    if not deg == 0:
        return height*math.tan(math.radians(deg))
    else:
        return 0

def make_outline(inner_dims,wall_thickness,grid_size,dims,alignment_offset):
    inner_dims=np.array(inner_dims)
    inner_outline=solid.square(inner_dims,center=True)
    outer_dims=inner_dims+wall_thickness
    outer_outline=solid.square(outer_dims,center=True)
    outline=solid.difference()(outer_outline,inner_outline)
    outline=solid.translate([grid_size[0]*dims[0]/2.0,grid_size[1]*dims[1]/2.0])(outline)
    return outline

def scale_percent_pdms_heat_shrinkage(temperature):
    scale_percent=1
    shrinkage=0
    if type(temperature) in (int,float):
        if 40 <= temperature <= 150:
            shrinkage = 0.0180*temperature + 0.46
            scale_percent=1+shrinkage/100.0
        else:
            temperature = None
    else:
        temperature = None
    if not temperature is None:
        text="Cure @ "+str(temperature)+"°C, "+str(shrinkage)+"% oversize compensating for shrinkage"
    else: text="Cure @ room temperature, no shrinkage compensation"
    return scale_percent,text


def make_water_wells(glass_size,glass_error,dims,grid_size):

    #make humidity reservoir in PDMS
    device_cut_x = glass_size[0]-glass_error
    device_cut_y = glass_size[1]-glass_error
    device_x = dims[0]*grid_size[0]
    device_y = dims[1]*grid_size[1]
    extra_space_x = device_cut_x-device_x
    extra_space_y = device_cut_y-device_y
    extra_space_tol = 4
    horizontal_well_width=extra_space_y/2.0-extra_space_tol
    horizontal_well_length=device_x+extra_space_x-extra_space_tol*2
    vertical_well_width=horizontal_well_width
    vertical_well_length=device_y+extra_space_y-extra_space_tol*2.0
    horizontal_well = solid.square([horizontal_well_length,horizontal_well_width],center=True)()
    vertical_well = solid.square([vertical_well_width,vertical_well_length],center=True)()
    
    def create_triangle(length):
        corner_x = length
        corner_y = length
        #               0       1        2        3         4          5
        corner_points=[[0,0,0],[0,corner_y,10],[0,corner_y,0],[0,corner_y,10],[corner_x,corner_y,10],[corner_x,corner_y,0]]
        return solid.polygon(points=corner_points)()
    
    corners_from_x_y = lambda x,y: [[-x/2.0,y/2.0], #top left
                                    [x/2.0, y/2.0], #top right
                                    [-x/2.0, -y/2.0],#bottom left
                                    [x/2.0, -y/2.0]] #bottom right
    horizontal_well_corners_pos=corners_from_x_y(horizontal_well_length,horizontal_well_width)
    
    #horizontal well
    triangle = create_triangle(vertical_well_width)
    triangle = solid.translate([0,-horizontal_well_width])(triangle)
    horizontal_well_triangle_left = solid.translate(horizontal_well_corners_pos[0])(triangle)
    triangle = solid.mirror([1,0,0])(triangle)
    horizontal_well_triangle_right = solid.translate(horizontal_well_corners_pos[1])(triangle)
    horizontal_well_triangles = solid.union()(horizontal_well_triangle_left,horizontal_well_triangle_right)
    horizontal_well_bottom = solid.difference()(horizontal_well,horizontal_well_triangles)
    for i in[-1,0,1]:
        split = solid.square([horizontal_well_width/2.0,horizontal_well_width],center=True)()
        split = solid.translate([i*horizontal_well_length/4.0,0])(split)
        horizontal_well_bottom = solid.difference()(horizontal_well_bottom,split)
    horizontal_well_bottom = solid.translate([0,-horizontal_well_width/2.0-device_y/2.0-extra_space_tol/2.0])(horizontal_well_bottom)
    horizontal_well_top = solid.mirror([0,1,0])(horizontal_well_bottom)
    horizontal_wells = solid.union()(horizontal_well_bottom,horizontal_well_top)
    
    vertical_well_corners_pos=corners_from_x_y(vertical_well_width,vertical_well_length)
    #vertical well
    triangle = create_triangle(horizontal_well_width)
    triangle = solid.translate([0,-vertical_well_width])(triangle)
    vertical_well_triangle_top = solid.translate(vertical_well_corners_pos[0])(triangle)
    triangle = solid.mirror([0,1,0])(triangle)
    vertical_well_triangle_bottom = solid.translate(vertical_well_corners_pos[2])(triangle)
    vertical_well_triangles = solid.union()(vertical_well_triangle_top,vertical_well_triangle_bottom)
    vertical_well_left = solid.difference()(vertical_well,vertical_well_triangles)
    for i in [-1,0,1]:
        split = solid.square([vertical_well_width,vertical_well_width/2.0],center=True)()
        split = solid.translate([0,i*vertical_well_length/4.0])(split)
        vertical_well_left = solid.difference()(vertical_well_left,split)
    vertical_well_left = solid.translate([device_cut_x/2.0-vertical_well_width/2.0-extra_space_tol/2.0,0])(vertical_well_left)
    #vertical_well_left = solid.translate([vertical_well_width/2.0+device_x/2.0+extra_space_tol/2.0,0])(vertical_well_left)
    vertical_well_right = solid.mirror([1,0,0])(vertical_well_left)
    vertical_wells = solid.union()(vertical_well_left,vertical_well_right)
    water_wells = solid.union()(vertical_wells,horizontal_wells)
    return water_wells







