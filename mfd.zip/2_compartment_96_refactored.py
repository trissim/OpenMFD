from make_device import *
base_path="./designs/open_chamber/2compartment_96well_refactored/"
design = "open"
wells_pos=4.5
well_rad=6.94/2.0

rows=1
columns=1
casing_x=9*2
casing_y=9

chan_gap=0.03
chan_w=0.01
#chan_l=1
well_gap=4.5
chan_l=(well_gap-well_rad)
chan_l_extra=chan_l*3
num_chans=int(well_rad/(chan_gap+chan_w))

chamber_len_until=well_gap
chamber_width=well_rad*2

grid_size = [6,8]
dims = [casing_x, casing_y, 0]
alignment_offset=[(dims[0]-casing_x*rows)/2.0,(dims[1]-casing_y*columns)/2]
units_from_center=(2,2)
alignment_mark_size=1

wafer_size=150
wafer_flat_len=57.5
wafer_thickness=0.625
outer_mask_thickness=3
wafer_line_thickness=0.3
#height of 3d printed walls
wall_height=10
#thickness of 3d printed walls
wall_thickness=1
wall_padx=9
wall_pady=9

wells_3d_height=1

#wafer_holder
margin=3
#notch dimensions that align with flat part of wafer
notch_len=10
notch_height=2
oversize=1.0025

#tip rack
rack_x=wafer_size+25
rack_y=wafer_size
rack_thickness=3
bolt_width=8
tip_rad=6.4/2

"""MAKE SINGLE UNIT"""
(chamber_wells_many_single,_),_,_=make_device(design=design,wells_pos=wells_pos,
                                         well_rad=well_rad,chan_l=chan_l,chan_w=chan_w,chan_gap=chan_gap,num_chans=num_chans,
                                         rows=rows,columns=columns,casing_x=casing_x,casing_y=casing_y,chamber_len_until=chamber_len_until,rotate_units=0,
                                              alignment=None,chamber_width=chamber_width)

_,(channels_many_single,_),_=    make_device(design=design,wells_pos=wells_pos,
                                        well_rad=well_rad,chan_l=chan_l*4,chan_w=chan_w,chan_gap=chan_gap,num_chans=num_chans,
                                        rows=rows,columns=columns,casing_x=casing_x,casing_y=casing_y,chamber_len_until=chamber_len_until,rotate_units=0,
                                              alignment=None,chamber_width=chamber_width)


"""SAVE FEATURES TOP AND BOTTOM LAYERS"""
save_model(channels_many_single,base_path,"open_duplicates_4mm_bottom")
save_model(chamber_wells_many_single,base_path,"open_duplicates_4mm_top")
save_model(solid.union()(chamber_wells_many_single,channels_many_single),base_path,"open_duplicates_4mm_aligned")


"""MAKE WALL"""
walls,wafer_wall,wafer_walls,= make_walls(wafer_size,wall_thickness,grid_size,dims,height=wall_height,segments=256,make_inner=False,padx=wall_padx,pady=wall_pady)
r.render(wafer_walls,outfile=osp.join(base_path,"wall_open_duplicates_4x4_walls.stl"))


"""MAKE OUTLINE FOR ALL DEVICES"""
outline = solid.translate([-alignment_offset[0],-alignment_offset[1]])(walls)
outline = solid.projection()(outline)


"""MAKE MULTI VERSION"""
#channels
open_duplicates_4mm_4x4_bottom = make_unit_array(channels_many_single,dims,grid_size, dxf=True, alignment = "full", units_from_center=units_from_center,alignment_offset=alignment_offset,alignment_mark_size=alignment_mark_size)
#add outline
open_duplicates_4mm_4x4_bottom = solid.union()(open_duplicates_4mm_4x4_bottom,outline)
#wells and chambers
open_duplicates_4mm_4x4_top = make_unit_array(chamber_wells_many_single,dims,grid_size, dxf=True, alignment = "hollow",units_from_center=units_from_center,alignment_offset=alignment_offset,alignment_mark_size=alignment_mark_size)
#both layers together
open_duplicates_4mm_4x4_aligned = solid.union()(open_duplicates_4mm_4x4_top,open_duplicates_4mm_4x4_bottom)
"""MAKE WALL"""
walls,wafer_wall,wafer_walls,= make_walls(wafer_size,wall_thickness,grid_size,dims,height=wall_height,segments=256,make_inner=False)
r.render(wafer_walls,outfile=osp.join(base_path,"wall_open_duplicates_4x4_walls.stl"))

"""PUT FEATURES IN MASK WITH A WAFER OUTLINE"""
#bottom layer
open_duplicates_4mm_4x4_bottom_final = add_wafer_to_mask(wafer_size,wafer_flat_len,open_duplicates_4mm_4x4_bottom,grid_size,dims,wafer_line_thickness=wafer_line_thickness,outer_mask_thickness=outer_mask_thickness,alignment_offset=alignment_offset)
#top layer
open_duplicates_4mm_4x4_top_final = add_wafer_to_mask(wafer_size,wafer_flat_len,open_duplicates_4mm_4x4_top,grid_size,dims,wafer_line_thickness=wafer_line_thickness,outer_mask_thickness=outer_mask_thickness,alignment_offset=alignment_offset)
#aligned
open_duplicates_4mm_4x4_aligned_final = add_wafer_to_mask(wafer_size,wafer_flat_len,open_duplicates_4mm_4x4_aligned,grid_size,dims,wafer_line_thickness=wafer_line_thickness,outer_mask_thickness=outer_mask_thickness,alignment_offset=alignment_offset)


"""SAVE MULTI VERSION"""
save_model(open_duplicates_4mm_4x4_bottom_final,base_path,"open_duplicates_4mm_4x4_bottom")
save_model(open_duplicates_4mm_4x4_top_final,base_path,"open_duplicates_4mm_4x4_top")
save_model(open_duplicates_4mm_4x4_aligned_final,base_path,"open_duplicates_4mm_4x4_aligned")


#"""MAKE 3D PRINTED WELL FEATURES"""
#(wells_many_single,_),_,_=make_device(design=design,wells_pos=wells_pos,
#                                              well_rad=well_rad,chan_l=chan_l,chan_w=chan_w,chan_gap=chan_gap,num_chans=num_chans,
#                                              rows=rows,columns=columns,casing_x=casing_x,casing_y=casing_y,chamber_len_until=chamber_len_until,rotate_units=0,
#                                              alignment=None,chamber_width=chamber_width)
#open_duplicates_4x4_wells = make_unit_array(wells_many_single,dims,grid_size, dxf=True, alignment = None,units_from_center=units_from_center,alignment_offset=alignment_offset,alignment_mark_size=alignment_mark_size)
#posts = make_posts(open_duplicates_4x4_wells,wells_3d_height,taper=0.8)
#save_model(posts,base_path,"open_duplicates_4mm_4x4_wells_taper",dxf=False)

"""MAKE 3D PRINTED WELL FEATURES_V2"""
degrees=25
taper_len=wells_3d_height*math.tan(math.radians(degrees))
(wells_many_single_top,_),_,_=make_device(design=design,wells_pos=wells_pos,
                                              well_rad=well_rad-taper_len,chan_l=chan_l+taper_len*2,chan_w=chan_w,chan_gap=chan_gap,num_chans=num_chans,
                                              rows=rows,columns=columns,casing_x=casing_x,casing_y=casing_y,chamber_len_until=chamber_len_until,rotate_units=0,
                                              alignment=None,chamber_width=chamber_width-taper_len*2)
open_duplicates_4x4_wells_1=chamfer_extrude(wells_3d_height,degrees,segments=20)(wells_many_single_top)
save_model(open_duplicates_4x4_wells_1,base_path,"open_duplicates_4x4_wells_1",dxf=False)
open_duplicates_4x4_wells = make_unit_array(wells_many_single_top,dims,grid_size, dxf=True, alignment = None,units_from_center=units_from_center,alignment_offset=alignment_offset,alignment_mark_size=alignment_mark_size)
open_duplicates_4x4_wells=chamfer_extrude(wells_3d_height,degrees,segments=20)(open_duplicates_4x4_wells)
bottom = solid.projection()(open_duplicates_4x4_wells)
bottom = solid.linear_extrude(height=wafer_thickness)(bottom)
open_duplicates_4x4_wells= solid.translate([0,0,wafer_thickness])(open_duplicates_4x4_wells)
open_duplicates_4x4_wells= solid.union()(open_duplicates_4x4_wells,bottom)
save_model(open_duplicates_4x4_wells,base_path,"open_duplicates_4x4_wells",dxf=False)

"""MAKE WAFER HOLDER"""
wafer_holder = make_wafer_empty(wafer_size,wafer_flat_len,wafer_thickness,margin,notch_len=notch_len,notch_height=notch_height,oversize=oversize)
wafer_holder = solid.translate([grid_size[1]*dims[1]/2.0,grid_size[0]*dims[0]/2.0])(wafer_holder)
wafer_holder=solid.translate([-alignment_offset[0],-alignment_offset[1]])(wafer_holder)
save_model(wafer_holder,base_path,"wafer_holder",dxf=False)

""" CREATE TIP RACK """
(wells,_),_,_=make_device(design=design,wells_pos=wells_pos,
                          well_rad=tip_rad,chan_l=chan_l,chan_w=chan_w,chan_gap=chan_gap,num_chans=num_chans,
                          rows=rows,columns=columns,casing_x=casing_x,casing_y=8,chamber_len_until=chamber_len_until,rotate_units=0,
                          alignment=None,chamber_width=chamber_width,add_chambers=False)
wells=make_unit_array(wells,dims,grid_size, dxf=True, alignment=None, units_from_center=units_from_center,alignment_offset=alignment_offset,alignment_mark_size=alignment_mark_size)
rack, rack_support = make_rack(wells,dims,grid_size,alignment_offset,rack_x,rack_y,rack_thickness,bolt_width)
save_model(rack,base_path,"rack",dxf=False)
save_model(rack_support,base_path,"rack_support",dxf=False)

#""" CREATE TIP RACK TEST"""
#(wells,_),_,_=make_device(design=design,wells_pos=4,
#                          well_rad=tip_rad,chan_l=chan_l,chan_w=chan_w,chan_gap=chan_gap,num_chans=num_chans,
#                          rows=rows,columns=columns,casing_x=casing_x,casing_y=8,chamber_len_until=chamber_len_until,rotate_units=0,
#                          alignment=None,chamber_width=chamber_width,add_chambers=False)
#grid_size = [1,1]
#rack_x=20
#rack_y=12.5
#rack_thickness=2
#wells=make_unit_array(wells,dims,grid_size, dxf=True, alignment=None, units_from_center=units_from_center,alignment_offset=alignment_offset,alignment_mark_size=alignment_mark_size)
#rack, rack_support = make_rack(wells,dims,grid_size,alignment_offset,rack_x,rack_y,rack_thickness,bolt_width,add_bolts=False)
#save_model(rack,base_path,"rack_test",dxf=False)
#save_model(rack_support,base_path,"rack_support_test",dxf=False)
