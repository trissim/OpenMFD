import solid
import os
import os.path as osp
from make_device import make_unit_array

def save_model(model,base_path,base_name):
    if not osp.exists(base_path):
        os.makedirs(base_path)
    scad_path=osp.join(base_path,base_name+".scad")
    solid.scad_render_to_file(model,osp.join(scad_path))


def create_rack(item_diameter,item_thickness,rack_height,base_name,base_path,item_diameter_extra=0,item_thickness_extra=0,rack_size_extra=0,grid_size=[1,1]):
    holder_size=(item_diameter+item_diameter_extra+rack_size_extra,item_diameter+item_diameter_extra+rack_size_extra)
    dims = [*holder_size, 0]
    height= item_thickness+item_thickness_extra
    radius=(item_diameter+item_diameter_extra)/2.0
    hole = solid.cylinder(r=radius, h=height, segments=64, center = True)
    hole = solid.translate([0,0,-height/2.0])(hole)
    holder = solid.cube((*holder_size,rack_height), center = True)
    holder = solid.translate([0,0,-rack_height/2.0])(holder)
    holder = solid.difference()(holder,hole)
    holder=make_unit_array(holder,dims,grid_size)
    save_model(holder,base_path,base_name)

version="v2"
base_path="./designs/plasma_racks/4mm_well_0.5inch_diam_device_"+version+"/"
#coverslip glass holder
item_diameter=18
item_diameter_extra=1
item_thickness=0.16
item_thickness_extra=0.04
rack_height=4
rack_size_extra=6
base_name="18CIR-1_rack_"+version
grid_size=[1,6]
create_rack(item_diameter,item_thickness,rack_height,base_name,base_path,item_diameter_extra=item_diameter_extra,item_thickness_extra=item_thickness_extra,rack_size_extra=rack_size_extra,grid_size=grid_size)

#0.5" diam device holder
item_diameter=15.8
item_diameter_extra=0
item_thickness=3
item_thickness_extra=0
rack_height=6
rack_size_extra=6
base_name="0.5inch_4mm_device_rack_"+version
grid_size=[1,6]
create_rack(item_diameter,item_thickness,rack_height,base_name,base_path,item_diameter_extra=item_diameter_extra,item_thickness_extra=item_thickness_extra,rack_size_extra=rack_size_extra,grid_size=grid_size)

